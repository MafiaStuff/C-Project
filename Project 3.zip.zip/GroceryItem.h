#include <string>
using namespace std;

class GroceryItem
{
public:
    /**
     * @brief Constructs a new GroceryItem object.
     *
     * @param itemName The name of the grocery item.
     * @param frequency The initial frequency count (default is 0).
     */
    GroceryItem(const std::string& itemName, int frequency = 0);

    /**
     * @brief Gets the name of the grocery item.
     *
     * @return std::string The name of the item.
     */
    std::string getName() const;

    /**
     * @brief Gets the frequency count of the grocery item.
     *
     * @return int The frequency count.
     */
    int getFrequency() const;

    /**
     * @brief Increments the frequency count by one.
     */
    void incrementFrequency();

    /**
     * @brief Sets the frequency count for the grocery item.
     *
     * @param frequency The new frequency count.
     */
    void setFrequency(int frequency);

    /**
     * @brief Prints the grocery item details.
     */
    void printItem() const;

private:
    std::string name;  /**< The name of the grocery item */
    int frequency;     /**< The frequency count of the grocery item */
};